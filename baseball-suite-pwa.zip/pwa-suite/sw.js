// ⚡ Baseball Suite Service Worker
// Caches both apps for offline use and fast loading

const CACHE = 'baseball-suite-v1';
const OFFLINE_URLS = [
  './',
  './index.html',
  './first-frame.html',
  './pitching-prophet.html',
  './ff-manifest.json',
  './pp-manifest.json',
];

// Install: pre-cache all pages
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(OFFLINE_URLS)).then(() => self.skipWaiting())
  );
});

// Activate: clear old caches
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch: cache-first for app shells, network-first for API calls
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);

  // Always go to network for external APIs (MLB, weather, ESPN, etc.)
  const isExternal = url.hostname !== self.location.hostname;
  if (isExternal) {
    e.respondWith(
      fetch(e.request).catch(() =>
        new Response(JSON.stringify({error:'offline'}), {
          headers: {'Content-Type':'application/json'}
        })
      )
    );
    return;
  }

  // Cache-first for local app files
  e.respondWith(
    caches.match(e.request).then(cached => {
      if (cached) return cached;
      return fetch(e.request).then(resp => {
        const clone = resp.clone();
        caches.open(CACHE).then(c => c.put(e.request, clone));
        return resp;
      });
    })
  );
});
